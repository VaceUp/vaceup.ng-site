"""Whiteboard app config."""

from django.apps import AppConfig


class WhiteboardConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.whiteboard"
    verbose_name = "Whiteboard"