# VaceUp LMS — Business Logic & Service Layer Design

**Companion to:** `vaceup-backend-docs.md` (architecture + data model) and `vaceup-erd` (schema diagram).
**This document answers:** *Where does logic live, and how does each core operation flow?*
**Stack context:** Django · DRF · MySQL · Celery.

The data model defines the system's **structure**; this document defines its **behavior**. Where the ERD says "an Enrollment has a Certificate," this says "*here* is exactly how a Certificate comes to exist, what must be true first, what it writes, and what fires afterward."

---

## 1. Layering Principle — Where Logic Lives

The single most important rule: **business logic lives in a service layer, not in views, serializers, or signals.** Views handle HTTP, serializers handle validation/representation, models handle data + invariants. Everything that *orchestrates* (touches multiple models, runs in a transaction, has side effects) is a **service**.

| Layer | File | Owns | Must NOT |
|---|---|---|---|
| **Model** | `models.py` | Fields, DB constraints, simple derived properties, single-object invariants | Cross-model orchestration, sending email, calling external APIs |
| **Selector** | `selectors.py` | Read logic — reusable, optimized querysets (dashboards, gated content, timetables) | Writes, side effects |
| **Service** | `services.py` | Write logic — business operations, transactions, orchestration, side effects, queuing tasks | HTTP/request objects, serialization |
| **Serializer** | `serializers.py` | Input validation, output shaping | Business decisions, DB writes beyond trivial `create`/`update` |
| **View / ViewSet** | `views.py` | Parse request → call selector/service → return response. Thin. | Any business logic |
| **Task** | `tasks.py` | Celery async work (email, PDFs, reminders) | Being the *source of truth* for a transaction |
| **Permission** | `permissions.py` | Authorization (who may call this) | Business rules unrelated to access |
| **Domain exception** | `exceptions.py` | Typed errors services raise | — |

### 1.1 Golden Rules
1. **Thin views.** A view method is: validate input (serializer) → call one service/selector → serialize output. If a view has an `if` about business state, that logic belongs in a service.
2. **Services own transactions.** Any operation writing to more than one table wraps in `@transaction.atomic`. The service is the transaction boundary.
3. **Side effects go through Celery.** Email, PDF generation, and external calls that aren't part of the correctness-critical transaction are queued *after* commit, not run inline.
4. **Signals are a last resort.** Prefer an explicit service call over a `post_save` signal — implicit magic makes flows hard to trace. Signals only for truly cross-cutting concerns (e.g. audit log).
5. **Selectors for reads, services for writes.** Views never build complex querysets inline; they call a named selector so query logic is testable and reusable.
6. **Idempotency where the outside world can retry** — payments and webhooks especially (see §4).

### 1.2 Per-App File Convention
```
apps/<domain>/
├── models.py          # data + invariants
├── selectors.py       # read/query logic
├── services.py        # write/business logic  ← the "logics"
├── serializers.py     # validation + representation
├── views.py           # thin HTTP layer
├── permissions.py     # authorization
├── tasks.py           # Celery async
├── exceptions.py      # domain exceptions
└── tests/
```

---

## 2. Domain State Machines

Most "logic" in an LMS is really **controlled state transitions**. Each stateful entity has a defined set of allowed transitions; services are the *only* place transitions happen, and they reject illegal ones. See the rendered diagram `vaceup-state-machines` for the visual; the rules:

**Application:** `pending → approved` · `pending → rejected` · `pending → withdrawn`. Terminal: approved / rejected / withdrawn.

**Payment:** `pending → success` · `pending → failed` · `success → refunded`. A `failed` payment can be retried by creating a *new* Payment (never resurrected).

**Enrollment:** `active → completed` (completion criteria met) · `active → suspended` (admin) · `suspended → active` (reinstated). `completed` is terminal for progress but the student retains access.

**Submission:** `submitted → graded`. `submitted` is flagged `late` at creation if past deadline (a property of *how* it entered, not a separate state).

**QuizAttempt:** `in_progress → submitted → graded`. Auto-graded types jump `submitted → graded` synchronously; attempts containing short-answer questions wait for manual grading.

**LiveClass:** `scheduled → live → completed` · `scheduled → cancelled`. `live` may be set manually or by a scheduled job at start time.

**Certificate:** `issued → revoked`. Revocation is soft (`is_revoked=True`), never a delete — the verification link must keep resolving (to "revoked").

**Transition guard pattern** (used everywhere):
```python
# core/state.py
def guard_transition(current, target, allowed: dict):
    if target not in allowed.get(current, ()):
        raise IllegalStateTransition(f"{current} → {target} not allowed")
```

---

## 3. Domain Exceptions

Services raise typed exceptions; a single DRF exception handler maps them to HTTP responses, so views never translate errors.

```python
# core/exceptions.py
class DomainError(Exception): ...                 # base → HTTP 400 by default
class IllegalStateTransition(DomainError): ...
class NotEnrolled(DomainError): ...               # → 403
class DeadlinePassed(DomainError): ...            # → 409
class PaymentVerificationError(DomainError): ...  # → 402
class AlreadyExists(DomainError): ...             # → 409
class CompletionCriteriaNotMet(DomainError): ...  # → 409
```
A custom `EXCEPTION_HANDLER` inspects the type and returns the consistent error envelope from `vaceup-backend-docs.md` §7.1.

---

## 4. Transactions, Idempotency & Consistency

- **Atomic services:** every multi-write service is `@transaction.atomic`. If any step fails, nothing persists.
- **Post-commit side effects:** queue Celery tasks with `transaction.on_commit(lambda: task.delay(...))` so a rolled-back transaction never sends a "payment confirmed" email.
- **Idempotency (critical for payments):** Paystack may call the webhook more than once, and the client may *also* hit verify. `confirm_payment` locks the row (`select_for_update`) and returns early if already `success` — processing exactly once regardless of how many times it's called.
- **Uniqueness as a safety net:** DB `UniqueConstraint`s (`(student, course)` on Enrollment, `(assignment, student)` on Submission, `(live_class, student)` on Attendance) make double-processing fail loudly rather than silently duplicating.
- **Denormalized fields** (`progress_percent`, `enrolled_count`) are only ever updated inside the service that owns the cause, so they can't drift.

---

## 5. Service Catalog

The core operations of the system, grouped by domain. Each service lists its **signature**, **preconditions** (what must be true), **steps** (the transaction), **side effects** (async), and **errors**. Pseudocode is representative Django, not final code.

### 5.1 Accounts

**`register_user(email, full_name, password, role='student', **profile) → User`**
- *Preconditions:* email not already registered.
- *Steps (atomic):* create `User(is_active=False)`; hash password; create the role's profile row; create an `EmailVerificationToken`.
- *Side effects:* `on_commit` → `send_email('verify_email', token_link)`.
- *Errors:* `AlreadyExists` if email taken.

**`verify_email(token) → User`**
- *Preconditions:* token exists, unused, unexpired.
- *Steps:* mark token used; set `user.is_active=True`.
- *Errors:* `DomainError` on invalid/expired token.

**`request_password_reset(email)`** → always returns success (never reveal whether the email exists); if it exists, create token + `on_commit` email.
**`reset_password(token, new_password)`** → validate token, set password, invalidate token + existing sessions/refresh tokens.

*Login* is `simplejwt`'s token endpoint — no custom service, but a `is_active` check blocks unverified users.

### 5.2 Admissions → Payment → Enrollment (the money path)

This is the most important flow in the system. See `vaceup-payment-flow` diagram.

**`submit_application(student, course, motivation='') → Application`**
- *Preconditions:* course published; student not already enrolled; no open application for this course.
- *Steps:* create `Application(status=pending)`.
- *Side effects:* `on_commit` → confirmation email; notify admins.

**`review_application(application, admin, decision) → Application`** *(admin)*
- *Preconditions:* application `pending`; `decision ∈ {approved, rejected}`.
- *Steps:* `guard_transition`; set status, `reviewed_by`, `decided_at`.
- *Side effects:* notify applicant.
> Note: whether payment requires prior approval is a business choice (§ open decisions). Default flow below allows pay-then-enroll without manual approval; approval gate is an optional switch.

**`initialize_payment(student, course, application=None) → dict`**
- *Preconditions:* course published; student not already enrolled with a `success` payment.
- *Steps (atomic):* create `Payment(status=pending, reference=uuid4())`; call Paystack `initialize`; store `gateway_reference`.
- *Returns:* `{authorization_url, reference}` for the client to redirect to.
- *Errors:* `PaymentVerificationError` if gateway init fails.

**`confirm_payment(reference, gateway_payload) → Payment`** — **idempotent, the linchpin**
```python
# payments/services.py
@transaction.atomic
def confirm_payment(*, reference, gateway_payload=None):
    payment = Payment.objects.select_for_update().get(reference=reference)
    if payment.status == Payment.Status.SUCCESS:
        return payment                      # already processed → no-op
    verified = paystack.verify(payment.gateway_reference)
    if not verified.ok or verified.amount_kobo != to_kobo(payment.amount):
        payment.mark_failed(gateway_payload)
        raise PaymentVerificationError(reference)
    payment.mark_success(paid_at=now(), raw_response=verified.payload)
    enrollment = enrollment_services.create_enrollment(
        student=payment.student, course=payment.course,
        application=payment.application,
    )
    transaction.on_commit(lambda: tasks.generate_receipt_pdf.delay(payment.id))
    transaction.on_commit(lambda: tasks.send_email.delay(
        "payment_confirmation", payment.student.email, {"course": payment.course_id}))
    return payment
```
- *Called by:* the webhook view **and** the client-verify view — both safe because of `select_for_update` + status check.
- *Never trusts client-reported amounts* — always re-verifies against Paystack and checks the amount.

**`create_enrollment(student, course, application=None) → Enrollment`**
- *Preconditions:* no active enrollment for `(student, course)`.
- *Steps:* create `Enrollment(status=active)`; if application, mark it `approved`; increment `course.enrolled_count`.
- *Guarded by:* `(student, course)` unique constraint as the final safety net.

### 5.3 Learning & Progress

**`mark_lesson_complete(enrollment, lesson) → LessonProgress`**
- *Preconditions:* lesson belongs to the enrollment's course; enrollment `active`.
- *Steps (atomic):* upsert `LessonProgress(completed=True)`; call `recompute_progress(enrollment)`; call `evaluate_completion(enrollment)`.
- *Errors:* `NotEnrolled` if the lesson isn't in the student's course.

**`recompute_progress(enrollment) → Decimal`**
- Pure calculation: `completed_lessons / total_lessons * 100`, stored on `enrollment.progress_percent`. Called by the service above (not a signal) so the trigger is explicit and testable.

**`evaluate_completion(enrollment)`**
- *Rule (configurable, see open decisions):* all lessons complete **and** all required assessments passed → transition `active → completed`, set `completed_at`, and call `certificates.issue_certificate(enrollment)`.
- *Otherwise:* no-op. Idempotent — safe to call after every lesson.

### 5.4 Live Classes

**`schedule_live_class(tutor, course, title, scheduled_at, duration, module=None) → LiveClass`** *(tutor)*
- *Preconditions:* tutor is assigned to the course; `scheduled_at` in the future.
- *Steps:* create `LiveClass(status=scheduled)`; Phase 2 → create Google Calendar event, store `meeting_link`.
- *Side effects:* notify enrolled students of the new class.

**`join_live_class(student, live_class) → str`**
- *Preconditions:* student actively enrolled; class within join window (e.g. from 15 min before start to end).
- *Steps:* upsert `Attendance(status=present|late)` based on `joined_at` vs `scheduled_at`.
- *Returns:* `meeting_link`.
- *Errors:* `NotEnrolled`; `DomainError` if outside join window.

**`send_class_reminders()`** *(Celery Beat, hourly)* — selector finds classes starting within the next hour with enrolled students; queues reminder emails/notifications.

### 5.5 Assignments

**`create_assignment(tutor, course, title, instructions, deadline, max_score, module=None) → Assignment`** *(tutor)* — validates tutor owns the course; `is_published` toggle controls student visibility.

**`submit_assignment(student, assignment, file, note='') → Submission`**
- *Preconditions:* student enrolled; assignment published.
- *Steps:* determine `late = now() > deadline`; upsert `Submission(status=submitted, late=late)`.
- *Side effects:* notify tutor of new submission.
- *Policy note:* submissions after deadline are **accepted but flagged `late`** (business default; a hard cutoff is a one-line change to raise `DeadlinePassed`).

**`grade_submission(tutor, submission, score, feedback) → Submission`** *(tutor)*
- *Preconditions:* tutor owns the assignment's course; `0 ≤ score ≤ max_score`.
- *Steps:* `guard_transition(submitted → graded)`; set score, feedback, `graded_by`, `graded_at`.
- *Side effects:* notify student "assignment graded".

### 5.6 Assessments (Quizzes)

**`start_quiz_attempt(student, quiz) → QuizAttempt`**
- *Preconditions:* student enrolled; quiz published; (optional) attempt limit not exceeded.
- *Steps:* create `QuizAttempt(status=in_progress, started_at=now())`.

**`submit_quiz_attempt(attempt, answers) → QuizAttempt`** — **auto-grading logic**
```python
@transaction.atomic
def submit_quiz_attempt(*, attempt, answers):
    guard_transition(attempt.status, "submitted", QUIZ_STATES)
    needs_manual = False
    total, earned = 0, 0
    for a in answers:
        q = a.question
        total += q.marks
        if q.question_type in ("mcq", "true_false"):
            correct = a.selected_choice and a.selected_choice.is_correct
            marks = q.marks if correct else 0
            earned += marks
            Answer.objects.create(attempt=attempt, question=q,
                                  selected_choice=a.selected_choice,
                                  awarded_marks=marks)
        else:  # short_answer → manual
            needs_manual = True
            Answer.objects.create(attempt=attempt, question=q,
                                  text_answer=a.text, awarded_marks=None)
    attempt.submitted_at = now()
    if needs_manual:
        attempt.status = "submitted"      # awaits tutor grading
    else:
        attempt.score = pct(earned, total)
        attempt.passed = attempt.score >= attempt.quiz.pass_mark_percent
        attempt.status = "graded"
        transaction.on_commit(lambda: evaluate_completion(enrollment_of(attempt)))
    attempt.save()
    return attempt
```
- Objective questions grade instantly; presence of a short-answer question defers to manual grading, after which the same scoring + `evaluate_completion` runs.

### 5.7 Certificates

**`issue_certificate(enrollment) → Certificate`**
- *Preconditions:* enrollment `completed`; no existing certificate (unique on enrollment).
- *Steps (atomic):* generate `certificate_number` (e.g. `VU-{year}-{seq}`) and `verification_uuid`; create `Certificate`.
- *Side effects:* `on_commit` → `generate_certificate_pdf.delay()` (WeasyPrint render → object storage), then notify student.
- *Idempotent:* if a certificate already exists, return it.

**`verify_certificate(verification_uuid) → dict`** *(public, read-only selector)* — returns holder name, course, issue date, and `valid = not is_revoked`. No auth.

**`revoke_certificate(admin, certificate, reason)`** *(admin)* — sets `is_revoked=True`; the verification link now resolves to "revoked" rather than 404.

### 5.8 Communications

**`create_announcement(author, title, body, course=None) → Announcement`**
- *Steps:* create announcement; resolve audience via selector — course announcement → actively enrolled students; academy-wide (`course=None`) → all active users.
- *Side effects:* fan-out `Notification` rows + optional email (batched via Celery).

**`notify(recipient, verb, payload)`** — internal helper every service uses to drop a `Notification`. This is *the* pattern for in-app alerts (grade posted, class scheduled, payment confirmed).

---

## 6. Selectors (Read Layer) — Key Queries

Reads that power dashboards and gated content live here, each optimized with `select_related`/`prefetch_related`.

- **`student_dashboard(student)`** → active/completed course counts, next upcoming class, pending assignments, overall progress. One assembled dict, minimal queries.
- **`tutor_dashboard(tutor)`** → assigned courses, student count, submissions pending grading, upcoming classes.
- **`student_timetable(student)`** → upcoming `LiveClass` for courses with an `active` enrollment, ordered by `scheduled_at`.
- **`enrolled_course_content(student, course)`** → modules → lessons → materials, **only if** an `active`/`completed` enrollment exists, else raise `NotEnrolled`. This is the content-gating enforcement point.
- **`admin_revenue(period)`** → sum of `success` payments grouped by period (see analytics, backend-docs §14).

The gating rule is enforced *in the selector*, not the view, so every path to course content goes through the same check.

---

## 7. Domain Event & Notification Catalog

Events that trigger notifications and/or emails, and the service that raises each:

| Event | Raised by | Notification | Email |
|---|---|---|---|
| Account created | `register_user` | — | Verify email |
| Application submitted | `submit_application` | Admin | Applicant confirmation |
| Application decided | `review_application` | Applicant | Yes |
| Payment confirmed | `confirm_payment` | Student | Receipt + welcome |
| Class scheduled | `schedule_live_class` | Enrolled students | Optional |
| Class starting soon | `send_class_reminders` | Enrolled students | Yes |
| Assignment submitted | `submit_assignment` | Tutor | — |
| Assignment graded | `grade_submission` | Student | Optional |
| Course completed | `evaluate_completion` | Student | Yes |
| Certificate issued | `issue_certificate` | Student | Yes |
| Announcement posted | `create_announcement` | Target audience | Optional |

---

## 8. Async Task Catalog (cross-ref backend-docs §9)

| Task | Trigger | Owner service |
|---|---|---|
| `send_email` | on_commit after many services | all |
| `process_paystack_webhook` | webhook view | wraps `confirm_payment` |
| `generate_receipt_pdf` | `confirm_payment` | payments |
| `generate_certificate_pdf` | `issue_certificate` | certificates |
| `send_class_reminders` | Beat (hourly) | liveclasses |
| `mark_completed_enrollments` | Beat (daily) | enrollment (calls `evaluate_completion`) |
| `fan_out_announcement` | `create_announcement` | communications |

---

## 9. Worked Example — One Vertical Slice (Enroll via Payment)

How the layers wire together for a single request, top to bottom:

```
POST /api/v1/payments/verify/   {reference}
        │
  views.PaymentVerifyView                 # thin: auth + parse
        │  serializer validates {reference}
        ▼
  payments.services.confirm_payment(...)  # @transaction.atomic  ← LOGIC
        ├─ Payment.objects.select_for_update()      (idempotency)
        ├─ paystack.verify()                        (external, verified)
        ├─ payment.mark_success()                   (state transition)
        ├─ enrollment.services.create_enrollment()  (cross-domain call)
        └─ on_commit → tasks.generate_receipt_pdf   (side effect, async)
                       tasks.send_email
        ▼
  serializer shapes {status, enrollment_id} → 200
```

Same `confirm_payment` is invoked by `POST /payments/webhook/` (signature-verified, no auth) — the client path and the server path converge on one idempotent service. **That convergence is the whole point of the service layer:** one place for the rule, many callers.

---

*End of document — VaceUp LMS Business Logic & Service Layer Design v1.0*
